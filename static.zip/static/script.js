let allProducts = [];
let cart = {};

async function loadProducts() {
    const response = await fetch("/api/products");
    allProducts = await response.json();

    const category = document.getElementById("category").value;

    const filtered = category === "All"
        ? allProducts
        : allProducts.filter(p => p.category === category);

    document.getElementById("products").innerHTML = filtered.map(p => `
        <div class="product">
            <img src="${p.image}" alt="${p.name}">
            <h3>${p.name}</h3>
            <p>Seller: ${p.seller}</p>
            <p>Price: ₹${p.price}</p>
            <p>Stock: ${p.stock}</p>
            <button onclick="addToCart(${p.id})"
                ${p.stock === 0 ? "disabled" : ""}>
                ${p.stock === 0 ? "Out of Stock" : "Add to Cart"}
            </button>
        </div>
    `).join("");
}

function addToCart(id) {
    const product = allProducts.find(p => p.id === id);
    const quantity = cart[id] || 0;

    if (quantity < product.stock) {
        cart[id] = quantity + 1;
    }

    renderCart();
}

function changeQuantity(id, change) {
    const product = allProducts.find(p => p.id === id);
    const newQuantity = (cart[id] || 0) + change;

    if (newQuantity <= 0) {
        delete cart[id];
    } else if (newQuantity <= product.stock) {
        cart[id] = newQuantity;
    }

    renderCart();
}

function renderCart() {
    let subtotal = 0;
    let sellers = {};

    Object.keys(cart).forEach(id => {
        const product = allProducts.find(p => p.id == id);
        const qty = cart[id];
        const amount = product.price * qty;

        subtotal += amount;

        if (!sellers[product.seller]) {
            sellers[product.seller] = [];
        }

        sellers[product.seller].push({
            name: product.name,
            qty,
            amount,
            id
        });
    });

    let html = "";

    for (const seller in sellers) {
        html += `<h3>${seller}</h3>`;

        sellers[seller].forEach(item => {
            html += `
                <p>
                    ${item.name} × ${item.qty}
                    = ₹${item.amount}
                    <button onclick="changeQuantity(${item.id}, -1)">−</button>
                    <button onclick="changeQuantity(${item.id}, 1)">+</button>
                </p>
            `;
        });
    }

    document.getElementById("cart").innerHTML =
        html || "Your cart is empty.";

    const gst = subtotal * 0.18;
    const total = subtotal + gst;

    document.getElementById("summary").innerHTML = `
        <p>Subtotal: ₹${subtotal.toFixed(2)}</p>
        <p>GST (18%): ₹${gst.toFixed(2)}</p>
        <h3>Final Total: ₹${total.toFixed(2)}</h3>
    `;
}

loadProducts();
renderCart();