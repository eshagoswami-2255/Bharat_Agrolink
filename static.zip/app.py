from flask import Flask, render_template, jsonify
import json

app = Flask(__name__)


def get_products():
  with open("products.json", "r", encoding="utf-8") as file:
    return json.load(file)


@app.route("/")
def home():
  return render_template("index.html")


@app.route("/api/products")
def products():
  return jsonify(get_products())


if __name__ == "__main__":
  app.run(debug=True)